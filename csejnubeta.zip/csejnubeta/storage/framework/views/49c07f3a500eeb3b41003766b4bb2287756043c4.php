<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="panel panel-default">
              <br>
              <br>
              <br>
                <a href="/notices/create" class="btn btn-warning">New notice</a>
                <a href="/" class="btn btn-warning">new classroom</a>
                <a href="/" class="btn btn-warning">start a research</a>
                <a href="/" class="btn btn-warning">make news</a>
                <a href="/" class="btn btn-warning">host event</a>
                <a href="/" class="btn btn-warning">profile</a>
                
                <br>
                <br>
                <br>
                <div class="panel-body">
                    <h3>My Previous notices</h3>
                    <?php if(count($notices) > 0): ?>
                        <table class="table table-striped">
                            <tr>
                                <th>Title</th>
                                <th></th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($notice->title); ?></td>
                                    <td><a href="/notices/<?php echo e($notice->id); ?>/edit" class="btn btn-default">Edit</a></td>
                                    <td>
                                        <?php echo Form::open(['action' => ['NoticesController@destroy', $notice->id], 'method' => 'notice', 'class' => 'pull-right']); ?>

                                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                            <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($notices->links()); ?>

                        </table>
                    <?php else: ?>
                        <p>No notices Found</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>