<?php $__env->startSection('content'); ?>

    <!--mahi-->
    <section class="section section-components">
      <h2 class="my-section-header display-1" style="text-align:center">csejnu today</h2>
      <br><br>
      <div class="container">


        <div class="container">


          <div class="row">
      
      
      
            <div class="col-sm-6" style="">
      
              <div class="contain">
                <img src="storage/news_images/news1.jpg" alt="Notebook" style="width:100%;">
                <div class="content">
                  <h1>Heading</h1>
                  <p>Lorem ipsum..</p>
                </div>
              </div>
      
      
              <div class="row justify-content-center" style="padding-top: 5px;">
      
                <div class="col-sm-6 ">
      
                  <div class="news-card card">
                    <div class="news-img">
                      <img class="card-img-top" src="storage/news_images/news2.jpg" alt="news Image">
                    </div>
      
                    <div class="card-body">
                      <a href="#" class="card-link news-link">Forensic image reconstruction based on efficient
                        morphological operational model</a>

                    </div>
                  </div>
      
                </div>
      
      
      
                <div class="col-sm-6 ">
      
                  <div class="news-card card">
                    <div class="news-img">
                      <img class="card-img-top" src="storage/news_images/news3.jpg" alt="news Image">
                    </div>
      
                    <div class="card-body">
                      <a href="#" class="card-link news-link">Forensic image reconstruction based on efficient
                        morphological operational model</a>
                    </div>
                  </div>
      
                </div>
      
              </div>
      
      
      
      
            </div>
      
      
      
            <div class="col-sm-6">
      
              <div class="card example-1 scrollbar-morpheus-den">
      
                <div class="card-body">
      
                  <h2 style="color: #172b4d;"><b>Latest News</b></h2>
      

                  <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <article class="event">
      
                    <div class="event-desc">
                      <h4 class="event-desc-header"><?php echo e($notice->title); ?></h4>
                      <p class="event-desc-detail"><span class="event-desc-time"></span>Posted on <?php echo e($notice->created_at); ?> by <?php echo e($notice->user->name); ?></p>
                      <a href="notices/<?php echo e($notice->id); ?>" target="_blank"
                        class="btn btn-default btn-sm">Details</a>
                    </div>
      
                  </article>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
      
      
 
                </div>
              </div>
      
      
            </div>
      
          </div>
      
      </div>
      <br><br>
      <div class="row justify-content-center">
        <a href="/notices" style="background:#c00" class="btn more-btn" >More News</a>
      </div>



      </div>














    </section>


<div style="height:2343px"></div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>