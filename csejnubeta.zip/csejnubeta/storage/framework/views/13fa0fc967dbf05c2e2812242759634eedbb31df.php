<?php $__env->startSection('content'); ?>
<section class="section section-lg pt-lg-0 section-contact-us">
        <div class="container">
          <div class="row justify-content-center mt-4">
            <div class="col-lg-12">
              <div class="card bg-gradient-secondary shadow">
                <div class="card-body p-lg-5">
                  <h4 class="mb-1">Create New Notice</h4>
                  <?php echo Form::open(['action' => 'NoticesController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                  <div class="form-group mt-5">
                    <div class="input-group input-group-alternative">
                      <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

                    </div>
                  </div>
                  
                  <div class="form-group mb-4">
                    <?php echo e(Form::textarea('description', '', ['id' => 'article-ckeditor', 'class' => 'form-control form-control-alternative', 'placeholder' => 'Type a message...'])); ?>

                  </div>
                  <div class="form-group mb-4">
                        <p>image limit under 2 mb</p><br>
                        <?php echo e(Form::file('notice_file', ['class'=>'btn btn-default btn-round btn-block btn-lg'])); ?>

                  </div>
                  
                  <div>
                    <?php echo e(Form::submit('Publish', ['class'=>'btn btn-default btn-round btn-block btn-lg'])); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>