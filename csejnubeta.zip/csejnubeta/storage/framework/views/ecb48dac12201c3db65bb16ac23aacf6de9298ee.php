<?php $__env->startSection('content'); ?>
<section class="section bg-secondary">
        <div class="container">
          <div class="row row-grid align-items-center">
            <div class="col-md-6">
              <div class="card bg-default shadow border-0">
                <img src="/storage/notice_files/<?php echo e($notice->notice_file); ?>" class="card-img-top">
              </div>
            </div>
            <div class="col-md-6">
              <div class="pl-md-5">
                <h3><?php echo e($notice->title); ?></h3>
                <p class="lead"><?php echo $notice->description; ?></p>
                <hr>
                <small>Written on <?php echo e($notice->created_at); ?> by <?php echo e($notice->user->name); ?></small>
                <hr>
                <div class="container row">
                        <?php if(!Auth::guest()): ?>
                        <?php if(Auth::user()->id == $notice->user_id): ?>
                            <div class="col-4">
                              <a href="/notices/<?php echo e($notice->id); ?>/edit" class="btn  btn-default col">Edit</a>                            
                            </div>
                            <?php echo Form::open(['action' => ['NoticesController@destroy', $notice->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger col'])); ?>

                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                </div>
            </div>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>