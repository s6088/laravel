<?php $__env->startSection('content'); ?>
<section class="section section-lg pt-lg-0 section-contact-us">
        <div class="container">
          <div class="row justify-content-center mt-4">
            <div class="col-lg-12">
              <div class="card bg-gradient-secondary shadow">
                <div class="card-body p-lg-5">
                  <h4 class="mb-1">Edit Notice</h4>
                  <?php echo Form::open(['action' => ['NoticesController@update', $notice->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                  <div class="form-group mt-5">
                    <div class="input-group input-group-alternative">
                            <?php echo e(Form::text('title', $notice->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

                        </div>
                  </div>
                  
                  <div class="form-group mb-4">
                        <?php echo e(Form::textarea('description', $notice->description, ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Dsscription'])); ?>

                    </div>
                  <div class="form-group mb-4">
                        <?php echo e(Form::file('notice_file')); ?>

                  </div>
                  
                  <div>
                        <?php echo e(Form::hidden('_method','PUT')); ?>

                        <?php echo e(Form::submit('Save', ['class'=>'btn btn-default btn-round btn-block btn-lg'])); ?>

                  </div>
                  <?php echo Form::close(); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>