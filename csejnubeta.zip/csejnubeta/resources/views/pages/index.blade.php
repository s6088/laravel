@extends('layouts.app')


@section('content')

    <!--mahi-->
    <section class="section section-components">
      <h2 class="my-section-header display-1" style="text-align:center">csejnu today</h2>
      <br><br>
      <div class="container">


        <div class="container">


          <div class="row">
      
      
      
            <div class="col-sm-6" style="">
      
              <div class="contain">
                <img src="storage/news_images/news1.jpg" alt="Notebook" style="width:100%;">
                <div class="content">
                  <h1>Heading</h1>
                  <p>Lorem ipsum..</p>
                </div>
              </div>
      
      
              <div class="row justify-content-center" style="padding-top: 5px;">
      
                <div class="col-sm-6 ">
      
                  <div class="news-card card">
                    <div class="news-img">
                      <img class="card-img-top" src="storage/news_images/news2.jpg" alt="news Image">
                    </div>
      
                    <div class="card-body">
                      <a href="#" class="card-link news-link">Forensic image reconstruction based on efficient
                        morphological operational model</a>

                    </div>
                  </div>
      
                </div>
      
      
      
                <div class="col-sm-6 ">
      
                  <div class="news-card card">
                    <div class="news-img">
                      <img class="card-img-top" src="storage/news_images/news3.jpg" alt="news Image">
                    </div>
      
                    <div class="card-body">
                      <a href="#" class="card-link news-link">Forensic image reconstruction based on efficient
                        morphological operational model</a>
                    </div>
                  </div>
      
                </div>
      
              </div>
      
      
      
      
            </div>
      
      
      
            <div class="col-sm-6">
      
              <div class="card example-1 scrollbar-morpheus-den">
      
                <div class="card-body">
      
                  <h2 style="color: #172b4d;"><b>Latest News</b></h2>
      

                  @foreach ($notices as $notice)
                  <article class="event">
      
                    <div class="event-desc">
                      <h4 class="event-desc-header">{{$notice->title}}</h4>
                      <p class="event-desc-detail"><span class="event-desc-time"></span>Posted on {{$notice->created_at}} by {{$notice->user->name}}</p>
                      <a href="notices/{{$notice->id}}" target="_blank"
                        class="btn btn-default btn-sm">Details</a>
                    </div>
      
                  </article>
                  @endforeach

      
      
      
 
                </div>
              </div>
      
      
            </div>
      
          </div>
      
      </div>
      <br><br>
      <div class="row justify-content-center">
        <a href="/notices" style="background:#c00" class="btn more-btn" >More News</a>
      </div>



      </div>














    </section>


<div style="height:2343px"></div>


@endsection